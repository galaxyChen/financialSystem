<?php
include 'model.php';
if (isset($_POST['add']))
{

}

?>