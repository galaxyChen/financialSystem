<?php
$linkcon=mysql_connect(SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT,SAE_MYSQL_USER,SAE_MYSQL_PASS) or die ("数据库链接失败");
mysql_select_db("app_syyey",$linkcon);
mysql_query("set names 'utf8'");
?>