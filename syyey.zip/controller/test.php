<?php
$date=explode('-', "2015-01-02");
print_r($date);
echo ($date[1]-2);


?>